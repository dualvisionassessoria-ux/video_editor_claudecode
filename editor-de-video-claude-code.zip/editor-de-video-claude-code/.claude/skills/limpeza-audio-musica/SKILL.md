---
name: limpeza-audio-musica
description: Remove ruído da voz (DeepFilterNet 3), mistura música de fundo baixinha com ducking, sintetiza SFX e normaliza em -14 LUFS. Use em toda edição de vídeo, antes de entregar.
---

# Áudio: limpar, musicar, normalizar

## Instalação (uma vez)
```bash
bash .claude/skills/limpeza-audio-musica/scripts/instalar_deepfilternet.sh
```
Instala torch (CPU) + deepfilternet, conserta o import `torchaudio.backend` em `df/io.py` e baixa o modelo DeepFilterNet3 de `raw.githubusercontent.com/Rikorose/DeepFilterNet` para o cache (o download automático do pacote costuma falhar).

## 1. Limpar a voz (sempre)
```bash
python3 .claude/skills/limpeza-audio-musica/scripts/limpar_ruido.py video.mp4 trabalho/video/voz_limpa.wav
# gravação de viva-voz / alto-falante:
python3 .../limpar_ruido.py video.mp4 voz_limpa.wav --misturar-original 0.13
```
- `--atten 18` (dB) é o ponto natural. Acima disso a voz fica aquosa.
- Faça isso **antes** da transcrição/decupagem para o corte por energia enxergar só a voz.

## 2. Música de fundo (sempre)
- ~**19 dB abaixo da voz**, ducking de ~45% enquanto há fala, fade in 1,5 s / out 1,2 s, sobe 60% no card final. A música nunca compete com a voz.
- Fontes sem direitos: freepd.com (domínio público/CC0) ou a música da pessoa. Prefira instrumental calmo/ambiente; respeite o clima do vídeo.
- Não há banco de música no repositório (por direitos). Baixe uma faixa e passe o caminho.

## 3. SFX (opcional, recomendado em vídeos com motion)
`gerar_sfx.py` sintetiza whoosh, pop, ding e ping, sem direitos autorais:
```bash
python3 .../gerar_sfx.py 40 trabalho/video/sfx.wav whoosh@1.5 pop@3.2 ding@8.0
```
Coloque um som na entrada de cada card/elemento, bem discreto.

## 4. Mixar e normalizar
```bash
python3 .../mixar_audio.py voz_final.wav musica.mp3 mix.wav --sfx sfx.wav --final-card 34
ffmpeg -i base.mp4 -i mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k -movflags +faststart final.mp4
```
`voz_final.wav` = áudio do vídeo já decupado e acelerado (`ffmpeg -i base.mp4 -vn -ac 1 -ar 48000 voz_final.wav`).
A saída fica em -14 LUFS / -1,2 dBTP.

## Conferir
```bash
ffmpeg -i final.mp4 -af ebur128=peak=true -f null - 2>&1 | tail -12   # I ~ -14 LUFS, true peak <= -1 dBTP
```
Se `loudnorm` direto estourar o pico, normalize a mistura para ~0,9 do fundo de escala antes (o script já faz) e/ou aplique `alimiter`.
