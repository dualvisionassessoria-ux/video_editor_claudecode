#!/usr/bin/env python3
"""Sintetiza efeitos sonoros simples (sem banco de sons, sem direitos autorais).

Uso: python3 gerar_sfx.py DURACAO_S saida.wav whoosh@1.5 pop@3.2 ding@8.0 ping@9.1

Efeitos: whoosh (entrada de card/transição), pop (elemento surge), ding (check/sucesso),
ping (notificação). Cada "nome@segundo" coloca o efeito naquele instante do vídeo final.
Use com: mixar_audio.py --sfx saida.wav
"""
import sys
import numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt

SR = 48000
rng = np.random.default_rng(7)
tt = lambda d: np.arange(int(d * SR)) / SR


def bp(x, lo, hi): return sosfilt(butter(2, [lo, hi], btype="band", fs=SR, output="sos"), x)


def sino(f, d, dec):
    t = tt(d)
    return (np.sin(2 * np.pi * f * t) + .35 * np.sin(2 * np.pi * f * 2.01 * t)) * np.exp(-t * dec) * np.minimum(1, t / .004)


def poe(tr, x, t, g=1.0):
    i = int(t * SR)
    if i < len(tr): j = min(len(tr), i + len(x)); tr[i:j] += x[:j - i] * g


def whoosh(d=.35):
    t = tt(d); n = rng.standard_normal(len(t)); y = np.zeros_like(t); seg = len(t) // 12
    for k in range(12):
        a, b = k * seg, (k + 1) * seg if k < 11 else len(t); c = 500 * (1 + k * .5); y[a:b] = bp(n, c, c * 2)[a:b]
    return y * np.sin(np.pi * t / d) ** 2 * .35


def pop(f=900, d=.14):
    t = tt(d); return np.sin(2 * np.pi * (f + 500 * np.exp(-t * 30)) * t) * np.exp(-t * 28) * .5


def ding():
    x = np.zeros(int(1.2 * SR)); poe(x, sino(1568, 1.2, 3.2), 0, .6); poe(x, sino(2349, 1.0, 3.5), .09, .45); return x * .5


def ping():
    x = np.zeros(int(1.1 * SR)); poe(x, sino(1318.5, .9, 5.5), 0, .55); poe(x, sino(1760, .9, 5.5), .11, .5); return x * .5


FX = dict(whoosh=whoosh, pop=pop, ding=ding, ping=ping)

if __name__ == "__main__":
    if len(sys.argv) < 4: sys.exit(__doc__)
    dur, saida = float(sys.argv[1]), sys.argv[2]
    tr = np.zeros(int(dur * SR) + SR)
    for item in sys.argv[3:]:
        nome, seg = item.split("@"); poe(tr, FX[nome](), float(seg))
    sf.write(saida, tr[: int(dur * SR)], SR, subtype="PCM_16"); print("sfx:", saida)
