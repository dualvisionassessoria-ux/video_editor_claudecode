#!/usr/bin/env python3
"""Remove ruído da fala com DeepFilterNet 3. Aceita vídeo ou áudio; salva WAV 48 kHz mono.

Uso: python3 limpar_ruido.py ENTRADA SAIDA.wav [--atten 18] [--misturar-original 0.0]

--atten              atenuação máxima do ruído em dB (18 = natural; subir deixa a voz "aquosa")
--misturar-original  fração do áudio original misturada de volta (0.13 para gravação de viva-voz /
                     alto-falante, onde a limpeza pura fica metálica)
"""
import argparse, os, subprocess, tempfile
import numpy as np, soundfile as sf, torch
from df.enhance import enhance, init_df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("entrada"); ap.add_argument("saida")
    ap.add_argument("--atten", type=float, default=18)
    ap.add_argument("--misturar-original", type=float, default=0.0)
    a = ap.parse_args()
    with tempfile.TemporaryDirectory() as d:
        raw = os.path.join(d, "raw.wav")
        subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", a.entrada, "-vn", "-ac", "1", "-ar", "48000", raw], check=True)
        x, sr = sf.read(raw, dtype="float32")
    model, state, _ = init_df()
    y = enhance(model, state, torch.from_numpy(x)[None], atten_lim_db=a.atten).squeeze(0).numpy()
    if a.misturar_original > 0:
        y = (1 - a.misturar_original) * y + a.misturar_original * x
    sf.write(a.saida, y, sr, subtype="PCM_16")
    print("limpo:", a.saida)


if __name__ == "__main__":
    main()
