#!/usr/bin/env bash
# Instala o DeepFilterNet 3 (remoção de ruído de voz) em CPU e aplica o conserto de compatibilidade.
set -e
python3 -m pip install -q torch torchaudio --index-url https://download.pytorch.org/whl/cpu
python3 -m pip install -q deepfilternet soundfile numpy scipy

# 1) conserto: torchaudio novo não tem mais torchaudio.backend.common.AudioMetaData
python3 - <<'PY'
import importlib.util, pathlib, re
spec = importlib.util.find_spec("df")
io = pathlib.Path(spec.submodule_search_locations[0]) / "io.py"
txt = io.read_text()
alvo = "from torchaudio.backend.common import AudioMetaData"
if alvo in txt:
    novo = ("from dataclasses import dataclass\n"
            "@dataclass\nclass AudioMetaData:\n    sample_rate: int = 0\n    num_frames: int = 0\n"
            "    num_channels: int = 0\n    bits_per_sample: int = 0\n    encoding: str = ''\n")
    io.write_text(txt.replace(alvo, novo))
    print("df/io.py corrigido")
else:
    print("df/io.py já está ok")
PY

# 2) modelo (o pacote tenta baixar sozinho e às vezes falha): baixa o zip do repositório oficial
CACHE="$(python3 -c "import appdirs;print(appdirs.user_cache_dir('DeepFilterNet'))" 2>/dev/null || echo "$HOME/.cache/DeepFilterNet")"
mkdir -p "$CACHE"
if [ ! -d "$CACHE/DeepFilterNet3" ]; then
  curl -sSL -o /tmp/DeepFilterNet3.zip https://raw.githubusercontent.com/Rikorose/DeepFilterNet/main/models/DeepFilterNet3.zip
  unzip -q -o /tmp/DeepFilterNet3.zip -d "$CACHE"
fi
echo "DeepFilterNet3 pronto em $CACHE"
