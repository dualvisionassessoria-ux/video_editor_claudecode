#!/usr/bin/env python3
"""Mixagem final: voz + música de fundo baixinha com ducking + normalização -14 LUFS.

Uso:
  python3 mixar_audio.py voz.wav musica.mp3 saida.wav [--db -19] [--sfx sfx.wav] [--final-card 0]

- A música entra ~19 dB abaixo da voz (RMS) e abaixa mais (ducking ~45%) enquanto há fala.
- Fade in de 1,5 s no início e fade out de 1,2 s no fim; se a música for curta, ela repete (loop).
- --sfx: trilha de efeitos já alinhada no tempo da voz (mesma duração), somada a 0,36x da voz.
- --final-card S: a partir do segundo S (tempo do vídeo final) a música sobe 60% (card/CTA final).
- Saída normalizada para -14 LUFS integrado, pico real -1 dBTP (padrão YouTube/Instagram).
Depois: ffmpeg -i base.mp4 -i saida.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k final.mp4
"""
import argparse, os, subprocess, tempfile
import numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt


def carregar(path, sr, dur=None):
    with tempfile.TemporaryDirectory() as d:
        w = os.path.join(d, "x.wav")
        cmd = ["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", path, "-ac", "1", "-ar", str(sr)]
        if dur: cmd += ["-t", str(dur)]
        subprocess.run(cmd + [w], check=True)
        x, _ = sf.read(w, dtype="float32")
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("voz"); ap.add_argument("musica"); ap.add_argument("saida")
    ap.add_argument("--db", type=float, default=-19, help="música em relação à voz (dB)")
    ap.add_argument("--duck", type=float, default=0.45)
    ap.add_argument("--sfx")
    ap.add_argument("--final-card", type=float, default=0)
    a = ap.parse_args()
    SR = 48000
    voz = carregar(a.voz, SR); N = len(voz); t = np.arange(N) / SR
    m = carregar(a.musica, SR)
    if len(m) < N: m = np.tile(m, int(np.ceil(N / len(m))))
    m = m[:N]
    # envelope da voz (suavizado) -> ducking
    env = sosfilt(butter(1, 6, btype="low", fs=SR, output="sos"), np.abs(voz))
    ref = np.percentile(env[env > 1e-4], 90) if (env > 1e-4).any() else 1.0
    duck = 1 - a.duck * np.clip(env / (ref + 1e-9), 0, 1)
    dur = N / SR
    g = np.clip(t / 1.5, 0, 1) * np.clip((dur - t) / 1.2, 0, 1)
    if a.final_card:
        g *= 1 + 0.6 * np.clip((t - a.final_card) / 0.4, 0, 1)
    vr = np.sqrt(np.mean(voz[np.abs(voz) > 0.02] ** 2)) if (np.abs(voz) > 0.02).any() else 0.1
    mr = np.sqrt(np.mean(m[np.abs(m) > 0.02] ** 2)) if (np.abs(m) > 0.02).any() else 0.1
    musica = m * g * duck * vr * 10 ** (a.db / 20) / mr
    mix = voz + musica
    if a.sfx:
        s = carregar(a.sfx, SR); s = np.pad(s, (0, max(0, N - len(s))))[:N]
        mix = mix + s * 0.36 * vr / 0.1
    mix = mix / max(1e-9, np.max(np.abs(mix))) * 0.9
    with tempfile.TemporaryDirectory() as d:
        bruto = os.path.join(d, "bruto.wav"); sf.write(bruto, mix, SR, subtype="PCM_16")
        subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", bruto, "-af",
                        "loudnorm=I=-14:TP=-1.2:LRA=9", "-ar", "48000", a.saida], check=True)
    print("mixagem pronta:", a.saida)


if __name__ == "__main__":
    main()
