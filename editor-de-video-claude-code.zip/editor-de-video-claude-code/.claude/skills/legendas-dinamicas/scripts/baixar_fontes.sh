#!/usr/bin/env bash
# Baixa fontes do Google Fonts (Montserrat ExtraBold, Instrument Serif, JetBrains Mono) para ./fontes
# Use quando o ffmpeg/libass ou o Chromium do Remotion não achar a fonte instalada no sistema.
set -e
mkdir -p fontes && cd fontes
for fam in "Montserrat:wght@800" "Instrument+Serif:ital@0;1" "JetBrains+Mono:wght@400"; do
  css=$(curl -sSL -A "curl/8.0" "https://fonts.googleapis.com/css2?family=${fam}&display=swap")
  echo "$css" | grep -o 'https://[^)]*\.\(ttf\|woff2\)' | while read -r u; do curl -sSL -O "$u"; done
done
ls
