#!/usr/bin/env python3
"""Gera legendas palavra a palavra (estilo Reels) em .ass a partir do edl.json do decupar.py.

Uso:
  python3 gerar_legendas_ass.py edl.json legendas.ass [--marca config/marca.json] [--palavras-chave "agenda,lead"]
  ffmpeg -i base.mp4 -vf "ass=legendas.ass:fontsdir=fontes" -c:a copy saida.mp4

- Grupos de até 3 palavras (quebra em pausa > 0,3 s, pontuação ou ~20 caracteres).
- Palavra falada agora: cor de destaque da marca + leve "pop"; as outras ficam brancas.
- Palavras-chave (lista) sempre na cor de destaque.
- Posição ~64% da altura, abaixo dos olhos, sem cobrir a boca. Minúsculas, sans pesada.
"""
import argparse, json, re


def bgr(hexcor):
    h = hexcor.lstrip("#"); r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H00{b}{g}{r}&".upper().replace("&H00", "&H00")


def tempo(s):
    h, r = divmod(max(0, s), 3600); m, r = divmod(r, 60)
    return f"{int(h)}:{int(m):02d}:{r:05.2f}"


def grupos(ws):
    out, cur = [], []
    for w in ws:
        quebra = cur and (len(cur) >= 3 or w["t0"] - cur[-1]["t1"] > 0.3 or re.search(r"[.?!]$", cur[-1]["p"])
                          or sum(len(x["p"]) + 1 for x in cur) + len(w["p"]) > 20)
        if quebra: out.append(cur); cur = []
        cur.append(w)
    if cur: out.append(cur)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("edl"); ap.add_argument("saida")
    ap.add_argument("--marca", default="")
    ap.add_argument("--palavras-chave", default="")
    ap.add_argument("--largura", type=int, default=1080); ap.add_argument("--altura", type=int, default=1920)
    a = ap.parse_args()
    marca = json.load(open(a.marca)) if a.marca else {}
    cor = bgr(marca.get("cor_destaque", "#2F95FF"))
    fonte = marca.get("fonte_titulo", "Montserrat")
    chaves = {x.strip().lower() for x in (a.palavras_chave.split(",") + marca.get("palavras_chave_legenda", [])) if x.strip()}
    ws = json.load(open(a.edl, encoding="utf-8"))["palavras"]
    cab = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {a.largura}
PlayResY: {a.altura}
WrapStyle: 2

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Pal,{fonte} ExtraBold,86,&H00FFFFFF&,&H00FFFFFF&,&H00000000&,&H80000000&,-1,0,0,0,100,100,0,0,1,5,3,5,60,60,{int(a.altura*0.0)},1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    linhas = []
    y = int(a.altura * 0.64)
    for g in grupos(ws):
        for k, w in enumerate(g):
            ini = w["t0"]; fim = g[k + 1]["t0"] if k + 1 < len(g) else max(w["t1"], w["t0"] + 0.25)
            partes = []
            for n, x in enumerate(g):
                txt = re.sub(r"[.,!;:]", "", x["p"]).lower()
                chave = txt.strip("?") in chaves
                if n == k: partes.append(r"{\c%s\fscx112\fscy112}%s{\c&H00FFFFFF&\fscx100\fscy100}" % (cor, txt))
                elif chave: partes.append(r"{\c%s}%s{\c&H00FFFFFF&}" % (cor, txt))
                else: partes.append(txt)
            linhas.append(f"Dialogue: 0,{tempo(ini)},{tempo(fim)},Pal,,0,0,0,,{{\\pos({a.largura//2},{y})}}" + " ".join(partes))
    open(a.saida, "w", encoding="utf-8").write(cab + "\n".join(linhas) + "\n")
    print(f"{len(linhas)} eventos em {a.saida}")


if __name__ == "__main__":
    main()
