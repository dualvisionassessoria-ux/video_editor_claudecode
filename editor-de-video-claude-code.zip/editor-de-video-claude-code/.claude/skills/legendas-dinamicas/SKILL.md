---
name: legendas-dinamicas
description: Legendas palavra a palavra no estilo Reels (destaque colorido na palavra falada) a partir do JSON da decupagem, via ffmpeg/ASS ou Remotion. Use quando o vídeo precisar de legenda.
---

# Legendas dinâmicas

Fonte dos tempos: `edl.json` do `decupar.py` (campo `palavras`, já no tempo do vídeo final).

## Padrão visual
- Palavra a palavra ou 2-3 palavras por vez, sincronizadas com a fala.
- Centralizada um pouco abaixo do meio (~60-70% da altura), nunca sobre a boca.
- Sans geométrica ExtraBold (Montserrat/Poppins), **minúsculas**, branca com sombra suave.
- Palavra falada agora (e as palavras-chave, 1 por frase) na cor de destaque da marca, com leve "pop".
- Variante caixa: texto branco sobre retângulo preto justo, palavra-chave em amarelo.
- Em vídeo horizontal não há legenda corrida: use título cinético só nas frases de impacto.
- Revise a grafia de marcas e nomes antes (a transcrição erra "ChatGPT", "Claude", etc.).

## Caminho rápido: ffmpeg + ASS
```bash
bash .claude/skills/legendas-dinamicas/scripts/baixar_fontes.sh        # se a fonte não estiver instalada
python3 .claude/skills/legendas-dinamicas/scripts/gerar_legendas_ass.py trabalho/video/edl.json trabalho/video/legendas.ass \
   --marca config/marca.json --palavras-chave "agenda,lead,cliente"
ffmpeg -i base.mp4 -vf "ass=trabalho/video/legendas.ass:fontsdir=fontes" -c:a copy legendado.mp4
```
A fonte padrão é "Montserrat ExtraBold" (troque em `fonte_titulo` da marca). O libass não lê woff2: o script de fontes baixa TTF.

## Caminho completo: Remotion
O componente `Legendas` em `motion-graphics-remotion/template/src/Legendas.tsx` faz o mesmo com animação (pop por palavra) e permite combinar com cards, HUD e CTA no mesmo render. Use quando houver motion graphics; caso contrário o ASS é mais rápido.
