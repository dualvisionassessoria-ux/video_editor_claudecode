# Guia de estilo de edição (o "DNA" dos vídeos profissionais de IA/tecnologia)

Destilado da análise de 6 vídeos de referência (3 Reels verticais e 3 vídeos horizontais): frames a cada 1 s (vertical) ou 4-5 s (horizontal), detecção de cena e medição de loudness com ffmpeg.

## 1. Ritmo
- **Gancho nos primeiros 3 s com um elemento gráfico já na tela.** Nenhum vídeo começa só com o rosto: título impactante, objeto 3D, número subindo.
- **Algo muda na tela a cada 1-3 s** nos verticais (legenda, card, zoom, troca de fundo). No horizontal 3-6 s por elemento, mas a intro (1-2 min) acelera para ~1 por segundo.
- **Decupagem seca:** sem respiração, pausa ou repetição. Jump cuts no mesmo enquadramento, disfarçados por **punch-in alternado** (100% -> 110-120%).
- **Capítulos visíveis:** "01 EDITOR", "04 MOTION", "13/28 Palavra por palavra", "Etapa 1".
- **CTA final de 3-5 s com palavra para comentar** ("COMENTA LEADS e recebe o passo a passo") ou card de inscrição/curso no horizontal.

## 2. Legendas (verticais)
- Palavra a palavra ou 2-3 palavras, centralizadas um pouco abaixo do meio (~60-70% da altura), nunca cobrindo a boca.
- Sans geométrica ExtraBold (Montserrat/Poppins), minúsculas, branca com sombra suave.
- Uma palavra-chave por frase na cor de destaque.
- Variante "caixa": texto branco sobre retângulo preto justo, palavra-chave em amarelo.
- No horizontal não há legenda corrida: o texto vira título cinético ou lower third só nas frases de impacto.

## 3. Tipografia de títulos
- Título curto em CAIXA ALTA pesada (2-3 palavras): "QUEM FEZ?", "CALMA", "MEDO DE GRAVAR".
- Contraste de estilos: sans pesada + **serif itálico fino** na segunda linha ("DUAS IAs. / *Você compara.*").
- **Mono pequeno e espaçado** para metadados de HUD ("EDITANDO AO VIVO 00:12:24", "LINHA DO TEMPO · 30 FPS").
- **Números gigantes animados** (contagem) para dados: "+2.000 leads", "31,7 mil", "64,4%".
- Pequenos ícones/sparkles ✦ ao lado dos títulos.

## 4. Cor
- **Fundo escuro + uma única cor de destaque por vídeo**, aplicada em legenda, bordas, barras e CTA (laranja, teal, coral, amarelo, azul...).
- Luz de cenário com cor na gravação (roxo, verde, abajur quente). Gradação leve: contraste alto, pretos profundos, pele preservada, sem LUT forte.

## 5. Motion graphics (o que mais diferencia)
- **Cards** com borda fina e cantos arredondados, vidro fosco ou escuro, slide + fade ~200-300 ms ease-out, às vezes inclinados em 3D.
- **HUD persistente** (barra superior com timer, capítulo, card de fonte no canto).
- **Reconstrução de UI real** (GitHub, chat, planilhas) como cards limpos com destaque, cursor clicando, digitação simulada.
- **Objetos 3D e infográficos:** barras 3D, globo/coração com rótulos e linhas de chamada, mapa de profundidade.
- **Recorte da pessoa** para trocar o cenário ou colocar texto **atrás** dela.
- **Linha do tempo de edição falsa** (faixas VÍDEO / LEGENDA / TRILHA / SFX / MOTION) como metáfora visual.
- **Transições:** corte seco + entrada de elemento; whip/zoom e desfoque rápido só entre blocos. Sem transições "de template".

## 6. Enquadramento e layouts
- Vertical: rosto no terço inferior quando há gráfico em cima; **tela dividida** (UI em cima, rosto embaixo).
- Horizontal: rosto deslocado para um lado e gráfico no outro; tela gravada com **webcam em PiP** (borda arredondada, canto direito).
- Card editorial em tela cheia com o rosto num quadro lateral.

## 7. Áudio
- Todos em **-14 LUFS integrado**, faixa dinâmica estreita (LRA 2-3 LU): voz comprimida e constante, sempre na frente.
- Trilha baixa e SFX (whoosh, pop, clique, "ding" de check) acompanhando a entrada de cada elemento.
- Microfone de lapela ou condensador próximo, sem eco.

## Receita para replicar
1. **Gravar:** fundo com luz de cor, rosto bem iluminado, microfone perto, espaço acima da cabeça no vertical.
2. **Decupar:** transcrição por palavra, cortar pausas > ~0,24 s, erros e repetições; punch-in alternado.
3. **Roteiro visual:** por frase, definir legenda, título cinético, card de dado/UI ou B-roll. Um elemento novo a cada 1-3 s.
4. **Identidade:** 1 cor de destaque, 1 sans pesada, 1 serif itálico, 1 mono, fundo escuro com grade sutil.
5. **Motion:** overlays em React (Remotion) ou HTML+GSAP (HyperFrames).
6. **Legendas:** palavra a palavra, palavra-chave em cor.
7. **Áudio:** voz limpa + trilha ~19 dB abaixo + SFX + -14 LUFS (pico -1 dBTP).
8. **CTA:** últimos 3-5 s com palavra para comentar.
9. **Exportar:** 1080x1920 30 fps (vertical) ou 1920x1080 (horizontal), H.264, ~12-20 Mbps.

## Stack usada
faster-whisper (transcrição), ffmpeg (cortes, zoom, mixagem, loudness), Remotion ou HyperFrames+GSAP (motion como código), DeepFilterNet 3 (ruído), rembg/RobustVideoMatting (recorte), yt-dlp (referências e B-roll).
