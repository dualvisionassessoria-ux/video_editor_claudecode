---
name: edicao-video
description: Editor de vídeo profissional completo (decupagem, áudio limpo, música, legendas e motion graphics) para Reels, Shorts e YouTube. Use quando a pessoa pedir para editar, cortar, legendar ou melhorar um vídeo.
---

# Edição de vídeo profissional (orquestrador)

Você é o editor. A pessoa grava; você entrega um vídeo enxuto, limpo, com legenda e motion graphics. Esta skill é o roteiro; as skills `decupagem-video`, `limpeza-audio-musica`, `legendas-dinamicas` e `motion-graphics-remotion` têm as ferramentas de cada etapa.

## Regras fixas (valem para TODO vídeo, sem a pessoa precisar pedir)

1. **Sem ruído:** toda fala passa pelo DeepFilterNet 3 (atenuação 18 dB). Em gravação de viva-voz/alto-falante, misture 13% do original para não soar metálico.
2. **Ritmo rápido, vídeo enxuto:** corte pausas acima de ~0,24 s (deixe ~0,07 s de cada lado) e acelere o vídeo inteiro em 1,1x (sem mudar o tom).
3. **Sem erros de fala:** corte repetições ("tá, tá", "muito, muito"), engasgos, enchimentos (ahn, é...) e frases emboladas. Ache-os com transcrição **literal**. Corte no vale de energia do áudio, nunca no meio de palavra.
4. **Sempre música de fundo, bem baixa:** ~19 dB abaixo da voz, com ducking enquanto há fala, subindo só no card final. Nunca compete com a voz. Sem música o vídeo soa robotizado. Use música livre de direitos (ex.: freepd.com, domínio público) ou a que a pessoa fornecer.
5. **Formato padrão vertical 1080x1920, 30 fps**, H.264, áudio normalizado em -14 LUFS (pico -1 dBTP). Horizontal (1920x1080) só se pedido.
6. **Revisões viram versões novas:** nunca sobrescreva. Entregue `nome-v1.mp4`, `nome-v2.mp4`, `nome-v3.mp4`... e diga o que mudou em cada uma.

## Configuração da marca

Leia `config/marca.json` (copie de `config/marca.exemplo.json`): nome, cor de destaque, fontes, CTA, formato. Se não existir, pergunte nome da marca e cor de destaque uma vez e crie o arquivo. Uma cor de destaque por vídeo, aplicada em legenda, bordas e CTA.

## Fluxo de trabalho

1. **Entender o pedido:** objetivo, público, plataforma, duração máxima (Reels/Shorts costumam ser <= 40-60 s) e se há CTA. Veja o vídeo (extraia frames com ffmpeg a cada 1 s) antes de editar.
2. **Preparar o ambiente** (uma vez por sessão): `bash .claude/skills/edicao-video/scripts/preparar_ambiente.sh`.
3. **Limpar áudio** -> `limpeza-audio-musica` (`limpar_ruido.py`).
4. **Transcrever literal** -> `decupagem-video` (`transcrever.py --literal`) e **decupar** (`decupar.py --audio voz_limpa.wav --vertical --renderizar`). Leia a lista `descartadas` do `edl.json` e releia a transcrição para pegar frases tortas que a máquina não vê; corte com `--descartar-intervalo`.
5. **Plano visual:** para cada frase decida: legenda simples, título, card de dado/UI, número gigante ou B-roll. Meta no vertical: algo novo a cada 1-3 s; gancho gráfico nos primeiros 3 s; capítulos visíveis em vídeos longos; CTA de 3-5 s no fim. Detalhes em `referencias/guia-de-estilo.md`.
6. **Legendas e motion** -> `legendas-dinamicas` (rápido, via ffmpeg/ASS) ou `motion-graphics-remotion` (cards, HUD, CTA, animações).
7. **Mixagem final** -> `limpeza-audio-musica` (`mixar_audio.py`, opcional `gerar_sfx.py`), muxar no vídeo e exportar.
8. **Conferir antes de entregar:** assista frames-chave, confira duração, sincronia da legenda, loudness (`ffmpeg -i f.mp4 -af ebur128 -f null -`), que a música não cobre a voz e que não restou erro de fala. Gere thumbnail se pedido.
9. **Entregar como versão N** e resumir em 3-4 linhas o que mudou e o que dá para ajustar.

## Dicas que economizam tempo

- Trabalhe em pasta `trabalho/` (já no `.gitignore`). Renderize intermediários em CRF 14-16 e só o final em ~12-20 Mbps.
- Se o arquivo final passar de um limite de envio (ex.: 25 MB), gere uma cópia leve 2-pass (~2,7 Mbps) para prévia e guarde a de alta qualidade.
- Peça a cor/logotipo/telefone do CTA em vez de inventar. Não use dado de cliente que a pessoa não forneceu.
- Mais lições técnicas: `docs/licoes-aprendidas.md`.
