#!/usr/bin/env bash
# Prepara o ambiente de edição (rode uma vez por sessão; contêineres/sandboxes são efêmeros).
set -e
command -v ffmpeg >/dev/null || { echo "Instale o ffmpeg (apt install ffmpeg / brew install ffmpeg / winget install ffmpeg)"; exit 1; }
python3 -m pip install -q numpy scipy soundfile faster-whisper "av<16"   # av<16: o PyAV novo quebra o faster-whisper
MODELO="${WHISPER_MODELO:-modelos/faster-whisper-large-v3-turbo}"
if [ ! -d "$MODELO" ]; then
  python3 -c "from huggingface_hub import snapshot_download; snapshot_download('mobiuslabsgmbh/faster-whisper-large-v3-turbo', local_dir='$MODELO')"
fi
echo "export WHISPER_MODELO=$MODELO   # use isto antes de rodar transcrever.py"
echo "Opcional: bash .claude/skills/limpeza-audio-musica/scripts/instalar_deepfilternet.sh"
echo "Opcional (motion): cd .claude/skills/motion-graphics-remotion/template && npm install"
