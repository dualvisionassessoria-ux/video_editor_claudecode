#!/usr/bin/env python3
"""Decupagem automática: corta pausas, repetições e engasgos, acelera e renderiza.

Entrada: vídeo + JSON do transcrever.py (de preferência com --literal).
Saída (pasta -o): edl.json (cortes + palavras já no tempo do vídeo final) e, com --renderizar, o vídeo.

Exemplo:
  python3 decupar.py video.mp4 trabalho/transcricoes/video.json -o trabalho/video \
      --audio trabalho/video/voz_limpa.wav --velocidade 1.1 --vertical --renderizar

Regras padrão (valem para todo vídeo):
  - pausas > 0,24 s são cortadas, deixando ~0,07 s de cada lado;
  - repetições imediatas ("tá, tá", "muito, muito", "tá perfeito, tá perfeito") ficam só com a última;
  - enchimentos (ahn, é, hum, éh) saem; use --remover para outros;
  - o corte cai no vale de energia do áudio, nunca no meio de palavra;
  - velocidade final 1,1x (atempo, mantém o tom).
Revise o edl.json (campo "descartadas") antes de entregar: a máquina erra frases tortas que só
uma leitura da transcrição pega. Use --descartar-intervalo INI-FIM (s, no tempo original) para cortar à mão.
"""
import argparse, json, os, re, subprocess, sys
import numpy as np, soundfile as sf

ENCHIMENTO = {"ahn", "ahn,", "hum", "hmm", "éh", "ãh", "ah", "uh", "é...", "é,"}
FPS_PADRAO = 30


def limpa(p):
    return re.sub(r"[^\wÀ-ÿ-]", "", p.lower())


def ler_palavras(path):
    d = json.load(open(path, encoding="utf-8"))
    ws = d.get("palavras") or [w for s in d["segmentos"] for w in s["palavras"]]
    return [dict(p=w["p"], t0=w.get("inicio", w.get("t0")), t1=w.get("fim", w.get("t1"))) for w in ws]


def audio_mono(path, sr=16000):
    tmp = path + ".tmp_decupar.wav"
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", path, "-vn", "-ac", "1", "-ar", str(sr), tmp], check=True)
    a, _ = sf.read(tmp, dtype="float32")
    os.remove(tmp)
    return a, sr


def envelope(a, sr, h=0.005):
    n = int(h * sr)
    k = len(a) // n
    return np.sqrt((a[: k * n].reshape(k, n) ** 2).mean(1)), h


def marcar_descartes(ws, remover, intervalos):
    """Devolve (mantidas, descartadas[{p,t0,t1,motivo}])."""
    rem = {limpa(x) for x in remover} | {limpa(x) for x in ENCHIMENTO}
    desc, flag = [], [True] * len(ws)
    for i, w in enumerate(ws):
        if limpa(w["p"]) in rem or not limpa(w["p"]):
            flag[i] = False; desc.append(dict(w, motivo="enchimento"))
        elif any(a <= w["t0"] and w["t1"] <= b + 0.05 for a, b in intervalos):
            flag[i] = False; desc.append(dict(w, motivo="manual"))
    # repetição de n-gramas (n=3..1) com intervalo curto: mantém a última ocorrência
    idx = [i for i in range(len(ws)) if flag[i]]
    for n in (3, 2, 1):
        i = 0
        while i + 2 * n <= len(idx):
            A, B = idx[i:i + n], idx[i + n:i + 2 * n]
            if all(limpa(ws[a]["p"]) == limpa(ws[b]["p"]) for a, b in zip(A, B)) and ws[B[0]]["t0"] - ws[A[-1]]["t1"] < 0.8:
                for a in A:
                    flag[a] = False; desc.append(dict(ws[a], motivo=f"repeticao x{n}"))
                idx = [j for j in idx if flag[j]]
            else:
                i += 1
    return [w for w, f in zip(ws, flag) if f], sorted(desc, key=lambda d: d["t0"])


def montar_cortes(ws, e, h, pausa, margem, dur_total):
    def vale(lo, hi):
        i0, i1 = max(0, int(lo / h)), min(len(e) - 1, max(1, int(hi / h)))
        if i1 <= i0: return lo
        return (i0 + int(np.argmin(e[i0:i1 + 1]))) * h
    runs, cur = [], [ws[0]]
    for w in ws[1:]:
        if w["t0"] - cur[-1]["t1"] > pausa: runs.append(cur); cur = [w]
        else: cur.append(w)
    runs.append(cur)
    segs = []
    for r in runs:
        ini = vale(r[0]["t0"] - 0.12, r[0]["t0"] - 0.01) if r[0]["t0"] > 0.15 else max(0, r[0]["t0"] - margem)
        fim = min(dur_total, vale(r[-1]["t1"] + 0.01, r[-1]["t1"] + 0.12))
        segs.append([round(ini, 3), round(fim, 3), r])
    for i in range(1, len(segs)):
        if segs[i][0] < segs[i - 1][1]: segs[i][0] = segs[i - 1][1]
    return segs


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video"); ap.add_argument("transcricao")
    ap.add_argument("-o", "--saida", default="trabalho/decupagem")
    ap.add_argument("--audio", help="áudio já limpo (wav 48 kHz) para usar no lugar do áudio do vídeo")
    ap.add_argument("--pausa", type=float, default=0.24)
    ap.add_argument("--margem", type=float, default=0.07)
    ap.add_argument("--velocidade", type=float, default=1.1)
    ap.add_argument("--fps", type=int, default=FPS_PADRAO)
    ap.add_argument("--remover", default="", help="palavras extras a cortar, separadas por vírgula")
    ap.add_argument("--descartar-intervalo", action="append", default=[], metavar="INI-FIM")
    ap.add_argument("--vertical", action="store_true", help="1080x1920 (corta o excesso no centro)")
    ap.add_argument("--renderizar", action="store_true")
    a = ap.parse_args()

    os.makedirs(a.saida, exist_ok=True)
    ws = ler_palavras(a.transcricao)
    inter = [tuple(map(float, x.split("-"))) for x in a.descartar_intervalo]
    mant, desc = marcar_descartes(ws, [x for x in a.remover.split(",") if x], inter)
    if not mant: sys.exit("nenhuma palavra restou")
    au, sr = audio_mono(a.audio or a.video)
    e, h = envelope(au, sr)
    dur_total = len(au) / sr
    segs = montar_cortes(mant, e, h, a.pausa, a.margem, dur_total)

    sp, t, out_words, out_segs = a.velocidade, 0.0, [], []
    for i, (s, en, r) in enumerate(segs):
        nf = max(2, round((en - s) * a.fps)); d = nf / a.fps
        out_segs.append(dict(i=i, src0=s, src1=round(s + d, 3), t0=round(t / sp, 3), t1=round((t + d) / sp, 3)))
        for w in r:
            out_words.append(dict(p=w["p"], t0=round((t + w["t0"] - s) / sp, 3), t1=round((t + w["t1"] - s) / sp, 3)))
        t += d
    edl = dict(video=a.video, audio=a.audio, velocidade=sp, fps=a.fps, duracao_original=round(dur_total, 2),
               duracao_final=round(t / sp, 2), segmentos=out_segs, palavras=out_words,
               descartadas=[dict(p=d["p"], t0=d["t0"], motivo=d["motivo"]) for d in desc])
    json.dump(edl, open(os.path.join(a.saida, "edl.json"), "w"), ensure_ascii=False, indent=1)
    print(f"{dur_total:.1f}s -> {t / sp:.1f}s ({len(segs)} cortes, {len(desc)} palavras descartadas)")
    if not a.renderizar: return

    seg_dir = os.path.join(a.saida, "segs"); os.makedirs(seg_dir, exist_ok=True)
    vf = "fps=%d,format=yuv420p" % a.fps
    if a.vertical:
        vf = "scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,crop=1080:1920," + vf
    lista = []
    for sg in out_segs:
        d = round(sg["src1"] - sg["src0"], 3); p = os.path.join(seg_dir, f"{sg['i']:03d}.mp4"); lista.append(p)
        cmd = ["ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", str(sg["src0"]), "-t", str(d), "-i", a.video]
        if a.audio: cmd += ["-ss", str(sg["src0"]), "-t", str(d), "-i", a.audio, "-map", "0:v", "-map", "1:a"]
        cmd += ["-vf", vf, "-af", f"aresample=48000,afade=t=in:d=0.01,afade=t=out:st={max(0, d - 0.015)}:d=0.015",
                "-c:v", "libx264", "-crf", "16", "-preset", "fast", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-ac", "2", p]
        subprocess.run(cmd, check=True)
    lst = os.path.join(seg_dir, "lista.txt")
    open(lst, "w").write("".join(f"file '{os.path.abspath(p)}'\n" for p in lista))
    base = os.path.join(a.saida, "base_1x.mp4")
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", base], check=True)
    final = os.path.join(a.saida, "base.mp4")
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", base, "-filter_complex",
                    f"[0:v]setpts=PTS/{sp},fps={a.fps}[v];[0:a]atempo={sp}[a]", "-map", "[v]", "-map", "[a]",
                    "-c:v", "libx264", "-crf", "16", "-preset", "fast", "-c:a", "aac", "-b:a", "256k", final], check=True)
    print("vídeo base:", final)


if __name__ == "__main__":
    main()
