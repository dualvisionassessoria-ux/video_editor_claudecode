#!/usr/bin/env python3
"""Transcreve vídeo/áudio com faster-whisper e salva JSON (palavra a palavra, com tempo) e SRT.

Uso:
  python3 transcrever.py VIDEO [-o PASTA_SAIDA] [--literal] [--contexto "termos do vídeo"]

--literal  mantém "ahn", "é...", repetições e gaguejos (use para achar erros de fala).
           Sem VAD, com prompt de fala solta. É o modo certo para decupagem.
Sem --literal: transcrição limpa, boa para legendas.
"""
import argparse, json, os, sys, time
from faster_whisper import WhisperModel

PROMPT_LITERAL = "Ahn, é... tá, tá. Então, é, tipo, né... tá perfeito, tá perfeito."


def ts(s):
    h, r = divmod(s, 3600)
    m, r = divmod(r, 60)
    return f"{int(h):02d}:{int(m):02d}:{int(r):02d},{int(round((r % 1) * 1000)):03d}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("entrada")
    ap.add_argument("-o", "--saida", default="trabalho/transcricoes")
    ap.add_argument("--modelo", default=os.environ.get("WHISPER_MODELO", "large-v3-turbo"),
                    help="nome do modelo ou pasta local (env WHISPER_MODELO)")
    ap.add_argument("--idioma", default="pt")
    ap.add_argument("--literal", action="store_true")
    ap.add_argument("--contexto", default="", help="nomes próprios e termos do vídeo, para acertar a grafia")
    a = ap.parse_args()

    os.makedirs(a.saida, exist_ok=True)
    nome = os.path.splitext(os.path.basename(a.entrada))[0]
    t0 = time.time()
    modelo = WhisperModel(a.modelo, device="cpu", compute_type="int8")
    prompt = (PROMPT_LITERAL + " " + a.contexto).strip() if a.literal else (a.contexto or None)
    segs, info = modelo.transcribe(a.entrada, language=a.idioma, word_timestamps=True,
                                   vad_filter=not a.literal, beam_size=5,
                                   initial_prompt=prompt, condition_on_previous_text=False)
    dados = {"arquivo": os.path.basename(a.entrada), "idioma": info.language,
             "duracao": round(info.duration, 2), "segmentos": [], "palavras": []}
    srt = []
    for i, s in enumerate(segs, 1):
        pal = [{"p": w.word.strip(), "inicio": round(w.start, 3), "fim": round(w.end, 3),
                "conf": round(w.probability, 2)} for w in (s.words or [])]
        dados["segmentos"].append({"inicio": round(s.start, 2), "fim": round(s.end, 2),
                                   "texto": s.text.strip(), "palavras": pal})
        dados["palavras"] += pal
        srt.append(f"{i}\n{ts(s.start)} --> {ts(s.end)}\n{s.text.strip()}\n")
    with open(os.path.join(a.saida, nome + ".json"), "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=1)
    with open(os.path.join(a.saida, nome + ".srt"), "w", encoding="utf-8") as f:
        f.write("\n".join(srt))
    print(f"{nome}: {info.duration:.0f}s de áudio em {time.time() - t0:.0f}s, "
          f"{len(dados['palavras'])} palavras", file=sys.stderr)


if __name__ == "__main__":
    main()
