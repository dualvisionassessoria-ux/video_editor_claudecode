---
name: decupagem-video
description: Transcreve a fala com tempo por palavra (faster-whisper) e corta pausas, repetições, engasgos e erros de fala, acelerando o vídeo em 1,1x. Use ao começar qualquer edição de vídeo com fala.
---

# Decupagem (cortar o que atrapalha)

## 1. Transcrever em modo literal
```bash
python3 .claude/skills/decupagem-video/scripts/transcrever.py video.mp4 --literal -o trabalho/transcricoes --contexto "nomes e termos do vídeo"
```
- Modelo `large-v3-turbo` (CPU int8, ~0,9x tempo real). Defina `WHISPER_MODELO` com a pasta baixada por `preparar_ambiente.sh`.
- `--literal` mantém "ahn", "é...", "tá, tá" e gaguejos (prompt com fala solta e sem VAD). É o que permite achar os erros. Sem `--literal` a saída é limpa, boa só para legenda.
- Saída: `NOME.json` (cada palavra com `inicio`, `fim`, `conf`) e `NOME.srt`.
- Marcas e termos saem errados com frequência (ex.: "chat EPT" para ChatGPT). Passe-os em `--contexto` e corrija no JSON antes de legendar.

## 2. Decupar
Use o áudio já limpo (veja `limpeza-audio-musica`):
```bash
python3 .claude/skills/decupagem-video/scripts/decupar.py video.mp4 trabalho/transcricoes/video.json \
  -o trabalho/video --audio trabalho/video/voz_limpa.wav --velocidade 1.1 --vertical --renderizar
```
O script: remove enchimentos e repetições imediatas (mantém a última ocorrência), junta as palavras em trechos, corta pausas > 0,24 s deixando ~0,07 s de margem, ajusta cada corte ao **vale de energia** (nunca no meio de palavra), concatena e acelera em 1,1x com `atempo`.
Gera `edl.json`: `segmentos` (tempo original -> final), `palavras` já no tempo do vídeo final (alimenta as legendas) e `descartadas` (para revisar).

## 3. Revisão humana da máquina (obrigatória)
- Leia a transcrição inteira procurando: frases recomeçadas ("o que eu... o que eu queria"), correções ("quer dizer"), palavras trocadas, trechos que a pessoa pediu para ignorar ("corta isso").
- Cada trecho ruim: `--descartar-intervalo INI-FIM` (segundos no tempo original), ou `--remover "palavra1,palavra2"`.
- Ao reler o resultado, confirme que nenhuma frase ficou sem sentido por causa de um corte.
- `conf` baixa nas palavras marca trechos para conferir de ouvido.

## 4. Punch-in
Para esconder jump cuts, alterne o enquadramento entre 100% e 110-120% de um corte para o outro (no Remotion com `scale`, ou com `zoompan`/`crop` no ffmpeg). Sem pausa, sem respiração entre falas.

## Ajustes finos
- Ruído alto na gravação: use limiar de energia mais alto (o script usa o mínimo local, que já tolera ruído leve); com viva-voz o ideal é decupar sobre o áudio **limpo**.
- Vídeo que não é fala (tour, B-roll): não decupe; corte por cena e acelere trechos mortos 1,25-2x.
