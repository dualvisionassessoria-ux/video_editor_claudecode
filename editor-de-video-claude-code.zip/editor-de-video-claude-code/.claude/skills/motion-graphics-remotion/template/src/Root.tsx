import React from 'react';
import {Composition} from 'remotion';
import dados from './dados.json';
import {Main} from './Main';
import {MARCA} from './marca';

export const Root: React.FC = () => (
  <Composition id="Video" component={Main} durationInFrames={Math.round(dados.duracao_final * MARCA.fps)} fps={MARCA.fps} width={MARCA.largura} height={MARCA.altura} />
);
