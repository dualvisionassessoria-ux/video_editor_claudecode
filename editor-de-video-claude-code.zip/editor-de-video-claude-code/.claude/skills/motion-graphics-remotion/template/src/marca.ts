// Identidade visual. Troque pelos valores de config/marca.json da pessoa.
export const MARCA = {
  nome: 'Minha Marca',
  destaque: '#2F95FF',
  destaque2: '#19C3FF',
  fundo: '#060A12',
  titulo: 'Montserrat, Arial Black, sans-serif',
  serif: "'Instrument Serif', Georgia, serif",
  mono: "'JetBrains Mono', monospace",
  cta: 'COMENTA QUERO e recebe o passo a passo',
  largura: 1080,
  altura: 1920,
  fps: 30,
};
