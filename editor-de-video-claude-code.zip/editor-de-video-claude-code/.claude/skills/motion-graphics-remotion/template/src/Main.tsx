import React from 'react';
import {AbsoluteFill, Audio, Easing, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import dados from './dados.json';
import {Legendas} from './Legendas';
import {MARCA} from './marca';

const ease = Easing.bezier(0.22, 1, 0.36, 1);

// Card genérico: entra com slide + fade (~0,3 s, ease-out), borda fina, cantos arredondados.
export const Card: React.FC<{t0: number; t1: number; titulo: string; sub?: string; y?: number}> = ({t0, t1, titulo, sub, y = 260}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  if (t < t0 || t > t1) return null;
  const p = interpolate(t, [t0, t0 + 0.3], [0, 1], {extrapolateRight: 'clamp', easing: ease});
  const sai = interpolate(t, [t1 - 0.2, t1], [1, 0], {extrapolateLeft: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 90, right: 90, top: y + (1 - p) * 40, opacity: p * sai, padding: '36px 44px', borderRadius: 36,
      background: 'rgba(10,14,24,.78)', border: `2px solid ${MARCA.destaque}`, backdropFilter: 'blur(14px)'}}>
      <div style={{fontFamily: MARCA.titulo, fontWeight: 800, fontSize: 74, color: '#fff', textTransform: 'uppercase', lineHeight: 1.05}}>{titulo}</div>
      {sub && <div style={{fontFamily: MARCA.serif, fontStyle: 'italic', fontSize: 58, color: MARCA.destaque2, marginTop: 10}}>{sub}</div>}
    </div>
  );
};

// HUD fixo no topo (timer/capítulo) para dar cara de "produto".
export const Hud: React.FC<{rotulo: string}> = ({rotulo}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = Math.floor(frame / fps);
  const tempo = `00:${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  return (
    <div style={{position: 'absolute', top: 70, left: 70, right: 70, display: 'flex', justifyContent: 'space-between', fontFamily: MARCA.mono, fontSize: 30, letterSpacing: 4, color: '#fff', opacity: .85}}>
      <span style={{color: MARCA.destaque}}>● {rotulo}</span><span>{tempo}</span>
    </div>
  );
};

// CTA final (últimos ~4 s): palavra-chave para comentar.
export const Cta: React.FC<{t0: number}> = ({t0}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = interpolate(frame / fps, [t0, t0 + 0.4], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: ease});
  return (
    <AbsoluteFill style={{background: `rgba(6,10,18,${0.82 * p})`, justifyContent: 'center', alignItems: 'center', opacity: p}}>
      <div style={{fontFamily: MARCA.titulo, fontWeight: 800, fontSize: 92, color: '#fff', textAlign: 'center', padding: '0 80px', lineHeight: 1.1}}>{MARCA.cta}</div>
      <div style={{fontFamily: MARCA.serif, fontStyle: 'italic', fontSize: 64, color: MARCA.destaque2, marginTop: 30}}>{MARCA.nome}</div>
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => {
  const dur = dados.duracao_final;
  return (
    <AbsoluteFill style={{background: MARCA.fundo}}>
      {/* Coloque o vídeo base (saída do decupar.py) em public/base.mp4 e a trilha final em public/audio.wav.
          Se base.mp4 já tiver o áudio mixado, remova o <Audio/>. */}
      {/* <OffthreadVideo src={staticFile('base.mp4')} style={{width: '100%', height: '100%', objectFit: 'cover'}} /> */}
      <Hud rotulo="CAPÍTULO 01" />
      <Card t0={0.5} t1={2.8} titulo="Título curto" sub="segunda linha em serif itálico" />
      <Legendas palavras={dados.palavras} />
      <Sequence from={Math.round((dur - 2.5) * MARCA.fps)}><Cta t0={0} /></Sequence>
    </AbsoluteFill>
  );
};
