import React from 'react';
import {Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {MARCA} from './marca';

export type Palavra = {p: string; t0: number; t1: number};
type Grupo = {t0: number; t1: number; palavras: Palavra[]};

// Agrupa em até 3 palavras; quebra em pausa > 0,3 s, pontuação ou ~20 caracteres.
export const agrupar = (ws: Palavra[]): Grupo[] => {
  const out: Grupo[] = [];
  let cur: Grupo | null = null;
  ws.forEach((w, i) => {
    const prev = ws[i - 1];
    const quebra =
      !cur ||
      cur.palavras.length >= 3 ||
      /[.?!]$/.test(cur.palavras[cur.palavras.length - 1].p) ||
      cur.palavras.reduce((n, x) => n + x.p.length + 1, 0) + w.p.length > 20 ||
      (prev && w.t0 - prev.t1 > 0.3);
    if (quebra) {
      cur = {t0: w.t0, t1: w.t1, palavras: []};
      out.push(cur);
    }
    cur!.palavras.push(w);
    cur!.t1 = w.t1;
  });
  return out;
};

export const Legendas: React.FC<{palavras: Palavra[]; chaves?: string[]; y?: number}> = ({palavras, chaves = [], y = 1230}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const grupos = React.useMemo(() => agrupar(palavras), [palavras]);
  const g = grupos.find((x, i) => t >= x.t0 - 0.02 && t < (grupos[i + 1]?.t0 ?? x.t1 + 0.3));
  if (!g) return null;
  return (
    <div style={{position: 'absolute', left: 60, right: 60, top: y, textAlign: 'center', fontFamily: MARCA.titulo, fontWeight: 800, fontSize: 86, lineHeight: 1.1}}>
      {g.palavras.map((w, n) => {
        const txt = w.p.replace(/[.,!;:]/g, '').toLowerCase();
        const ativa = t >= w.t0 && t < (g.palavras[n + 1]?.t0 ?? g.t1 + 0.3);
        const chave = chaves.includes(txt.replace('?', ''));
        const pop = ativa ? interpolate(t - w.t0, [0, 0.12], [0.86, 1.08], {extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)}) : 1;
        return (
          <span key={n} style={{display: 'inline-block', margin: '0 12px', color: ativa || chave ? MARCA.destaque : '#fff', transform: `scale(${pop})`,
            textShadow: '0 4px 0 rgba(0,0,0,.35), 0 8px 30px rgba(0,0,0,.65)'}}>{txt}</span>
        );
      })}
    </div>
  );
};
