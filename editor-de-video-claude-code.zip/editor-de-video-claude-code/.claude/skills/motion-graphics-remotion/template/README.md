# Template Remotion

1. `npm install`
2. Copie o `edl.json` do `decupar.py` para `src/dados.json` (campos `duracao_final` e `palavras`).
3. Coloque o vídeo base em `public/base.mp4` e descomente a linha do `<OffthreadVideo>` em `src/Main.tsx`.
4. Ajuste `src/marca.ts` (cores/fontes) e os cards em `Main.tsx`.
5. `npm run preview` para ver, `npm run render` para gerar `saida.mp4`.

Fontes: o Chromium do Remotion pode não confiar em proxy/CA corporativo. Se as fontes do Google não carregarem,
baixe com `legendas-dinamicas/scripts/baixar_fontes.sh` para `public/fonts` e carregue com `FontFace` + `delayRender`.
Em contêiner/Linux sem Chrome, use `--browser-executable=<caminho do chromium> --chrome-mode=headless-shell`.
