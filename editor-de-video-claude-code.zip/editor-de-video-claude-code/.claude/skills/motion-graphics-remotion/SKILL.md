---
name: motion-graphics-remotion
description: Cria cards, títulos cinéticos, HUD, números animados, mockups de UI e CTA como código (Remotion/React) e renderiza sobre o vídeo. Use quando o vídeo precisar de elementos gráficos além de legenda.
---

# Motion graphics com Remotion

Template pronto em `.claude/skills/motion-graphics-remotion/template/` (React + Remotion 4, vertical 1080x1920, 30 fps). Leia o `README.md` dele para o passo a passo.

## Receita
1. `cd .claude/skills/motion-graphics-remotion/template && npm install`.
2. Copie `edl.json` do `decupar.py` para `src/dados.json`; ponha o vídeo base em `public/base.mp4`; ajuste `src/marca.ts` com a identidade (`config/marca.json`).
3. Monte as cenas em `src/Main.tsx` com `Card`, `Hud`, `Cta`, `Legendas` (já inclusos) e componentes novos. Temporize tudo em **segundos do vídeo final**, a partir das palavras do `edl.json` (ex.: card aparece quando a palavra-chave é dita).
4. `npm run preview` para conferir; `npm run render` gera `saida.mp4` (H.264). Para sobrepor num vídeo já pronto, renderize só o overlay ou use `OffthreadVideo` como fundo.

## Linguagem visual (o que dá cara profissional)
- **Fundo escuro + UMA cor de destaque** (legenda, bordas, barras, CTA). Grade sutil e brilho radial no fundo.
- **Cards** com borda fina, cantos arredondados, vidro fosco; entram com slide + fade de ~0,3 s (`Easing.bezier(0.22,1,0.36,1)`), saem em 0,2 s. Nunca transições de template (cubo, page turn).
- **Tipografia:** título curto em CAIXA ALTA pesada (2-3 palavras) + segunda linha em **serif itálico** + mono pequeno e espaçado para metadados de HUD.
- **Números gigantes animados** (contagem) para dados: "+2.000 leads", "R$ 0", "07:00".
- **HUD persistente** (barra superior com timer/capítulo) e **capítulos numerados** dão cara de produto.
- **Reconstruir UIs reais** (WhatsApp, planilha, painel) como cards limpos com destaque, cursor clicando, digitação simulada, celular com "shake" na notificação.
- **Recorte da pessoa** (rembg / RobustVideoMatting) para trocar cenário ou colocar texto atrás dela.
- **Ritmo:** um elemento novo a cada 1-3 s no vertical; gancho gráfico nos primeiros 3 s; CTA final de 3-5 s com palavra para comentar.
- **Câmera virtual:** zoom/pan suave (`interpolate` + `Easing.inOut(Easing.cubic)`) sobre a cena; punch-in alternado nos cortes.

## Armadilhas conhecidas
- Em contêiner sem Chrome: `--browser-executable=<chromium> --chrome-mode=headless-shell`.
- Chromium atrás de proxy com CA própria não carrega fontes do Google: baixe os arquivos (`legendas-dinamicas/scripts/baixar_fontes.sh`), coloque em `public/fonts` e carregue com `FontFace` + `delayRender/continueRender`.
- Renderize a 1440x2560 e reduza só se precisar de nitidez extra em recortes com zoom.
- Vídeo longo no Remotion é lento em CPU: renderize com `--concurrency` igual ao número de núcleos e em partes.

## Alternativa
HyperFrames (HeyGen) + GSAP gera overlays em HTML/CSS com fundo transparente: ver https://github.com/heygen-com/hyperframes.
