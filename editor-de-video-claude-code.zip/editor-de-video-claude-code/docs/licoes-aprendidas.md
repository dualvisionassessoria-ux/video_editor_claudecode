# Lições aprendidas (armadilhas técnicas e decisões)

## Transcrição
- `faster-whisper` 1.2 quebra com PyAV 16+ (`metadata_errors`): instale `"av<16"`.
- `large-v3-turbo` (~1,6 GB) acerta mais que `medium` em português e é mais rápido na CPU (~0,9x tempo real).
- Para achar erros de fala use transcrição **literal**: `initial_prompt` com "Ahn, é... tá, tá", sem VAD, `condition_on_previous_text=False`.
- Marcas saem erradas ("cloud" por Claude, "chat EPT"); passe `--contexto` e corrija o JSON.

## Corte
- Corte sempre no **vale de energia** (RMS a cada 5 ms) a até 0,12 s da palavra; cortar no tempo da palavra corta o som da consoante.
- Fade de 10-15 ms em cada ponta de segmento evita cliques.
- Duração de cada segmento arredondada ao frame (30 fps) para áudio e vídeo não derivarem.
- Em viva-voz a voz da outra ponta é fraca: use limiar de energia menor (~ -38 a -29 dB) e decupe sobre o áudio já limpo.
- Acelerar: `setpts=PTS/1.1` no vídeo e `atempo=1.1` no áudio; tempos das palavras divididos pela mesma velocidade.

## Áudio
- DeepFilterNet 3 a 48 kHz, `atten_lim_db=18`. Em alto-falante, misture ~13% do original.
- `loudnorm` direto num mix com picos estoura o true peak: normalize a mistura a ~0,9 do fundo de escala antes e, se precisar, use `alimiter`.
- Música em ~-19 dB da voz (RMS) com ducking 45%; sem música o vídeo soa "robotizado".
- SFX sintetizados (numpy/scipy) evitam problema de direitos e de banco de sons.

## Remotion / render
- Sandbox sem Chrome: `--browser-executable` + `--chrome-mode=headless-shell`.
- Chromium atrás de proxy não confia na CA: baixe as fontes e carregue localmente (`FontFace` + `delayRender`).
- Renderize em CRF 14-16; reencode final para ~12-20 Mbps.

## Entrega
- Limites de transferência de arquivo (ex.: 25 MB) pedem uma cópia leve 2-pass (~2,7 Mbps) além da versão em alta qualidade.
- Nunca sobrescreva: cada revisão é `-v2`, `-v3`...
- Para vídeos sem fala (tour, B-roll): recorte caixas/legendas queimadas, acelere trechos mortos 1,25-2x, títulos por cena como PNG sobrepostos com ffmpeg, whoosh nas trocas, áudio normalizado -14 LUFS.
